// ─────────────────────────────────────────────────────────
//  scheduler.js — Agendador de lembretes WhatsApp
//  Roda a cada 30 minutos verificando quem precisa de aviso
// ─────────────────────────────────────────────────────────
const cron = require('node-cron');
const {
  notifyReminderDay,
  notifyReminderHour,
  notifyOwnerReminder,
} = require('./whatsapp');

/**
 * Retorna a data de hoje e amanhã em formato YYYY-MM-DD
 */
function getDateStrings() {
  const now       = new Date();
  const today     = now.toISOString().split('T')[0];
  const tomorrow  = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];
  return { now, today, tomorrowStr };
}

/**
 * Retorna HH:MM atual e HH:MM daqui 1 hora
 */
function getTimeWindow() {
  const now    = new Date();
  const pad    = n => String(n).padStart(2, '0');
  const curH   = now.getHours();
  const curM   = now.getMinutes();
  const oneAheadH = curH + 1;

  const currentTime  = `${pad(curH)}:${pad(curM)}`;
  const oneHourAhead = `${pad(oneAheadH)}:00`;
  const oneHourAhead30 = `${pad(oneAheadH)}:30`;

  return { currentTime, oneHourAhead, oneHourAhead30 };
}

/**
 * Inicializa o scheduler recebendo a instância do banco de dados
 */
function startScheduler(db) {
  console.log('⏰ Scheduler de lembretes iniciado (verifica a cada 30 minutos)');

  // Roda a cada 30 minutos
  cron.schedule('*/30 * * * *', async () => {
    console.log('\n🔄 Scheduler: verificando lembretes...');

    try {
      const { now, today, tomorrowStr } = getDateStrings();
      const { oneHourAhead, oneHourAhead30 } = getTimeWindow();

      // Busca todos os agendamentos confirmados ainda não notificados
      const appts = db.prepare(`
        SELECT * FROM appointments
        WHERE status = 'confirmed'
        AND date >= ?
      `).all(today);

      for (const appt of appts) {
        // ── Lembrete 1 DIA ANTES ───────────────────────
        // Dispara se o atendimento é amanhã e ainda não enviou lembrete do dia
        if (appt.date === tomorrowStr && !appt.reminded_day) {
          console.log(`📅 Enviando lembrete D-1 para ${appt.clientName} (${appt.date} às ${appt.time})`);
          await notifyReminderDay(appt);
          db.prepare(`UPDATE appointments SET reminded_day = 1 WHERE id = ?`).run(appt.id);
        }

        // ── Lembrete 1 HORA ANTES ─────────────────────
        // Dispara se o atendimento é hoje e está na janela de 1h à frente
        if (appt.date === today && !appt.reminded_hour) {
          const apptTime = appt.time; // "HH:MM"
          if (apptTime === oneHourAhead || apptTime === oneHourAhead30) {
            console.log(`⏰ Enviando lembrete H-1 para ${appt.clientName} (hoje às ${appt.time})`);
            await notifyReminderHour(appt);
            await notifyOwnerReminder(appt);
            db.prepare(`UPDATE appointments SET reminded_hour = 1 WHERE id = ?`).run(appt.id);
          }
        }
      }

      console.log(`✅ Verificação concluída: ${appts.length} agendamento(s) analisados.`);
    } catch (err) {
      console.error('❌ Erro no scheduler:', err.message);
    }
  });

  // Também roda uma vez ao iniciar o servidor (para não perder lembretes pendentes)
  console.log('🔄 Executando verificação inicial de lembretes...');
}

module.exports = { startScheduler };
