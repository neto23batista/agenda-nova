// ─────────────────────────────────────────────────────────
//  server.js — Belle Studio Backend
//  Express + SQLite + WhatsApp + Cron
// ─────────────────────────────────────────────────────────
require('dotenv').config();

const express  = require('express');
const cors     = require('cors');
const Database = require('better-sqlite3');
const path     = require('path');
const {
  notifyConfirmation,
  notifyOwnerNewBooking,
} = require('./whatsapp');
const { startScheduler } = require('./scheduler');

const app  = express();
const PORT = process.env.PORT || 3001;

// ── Middleware ───────────────────────────────────────────
app.use(cors());
app.use(express.json());

// Serve o frontend estático (coloque o index.html na pasta /public)
app.use(express.static(path.join(__dirname, 'public')));

// ── Banco de dados SQLite ────────────────────────────────
const db = new Database(path.join(__dirname, 'belle.db'));

// ── Criação das tabelas ──────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS services (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    icon        TEXT,
    duration    INTEGER,
    price       REAL,
    active      INTEGER DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS clients (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    phone       TEXT NOT NULL,
    email       TEXT,
    notes       TEXT,
    created_at  TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS appointments (
    id            TEXT PRIMARY KEY,
    client_id     TEXT,
    clientName    TEXT,
    clientPhone   TEXT,
    serviceId     TEXT,
    serviceName   TEXT,
    date          TEXT NOT NULL,
    time          TEXT NOT NULL,
    status        TEXT DEFAULT 'pending',
    notes         TEXT,
    reminded_day  INTEGER DEFAULT 0,
    reminded_hour INTEGER DEFAULT 0,
    created_at    TEXT DEFAULT (datetime('now')),
    updated_at    TEXT
  );
`);

// ── Seed inicial ─────────────────────────────────────────
function seedIfEmpty() {
  const count = db.prepare('SELECT COUNT(*) as n FROM services').get();
  if (count.n > 0) return;

  const uid = () => Math.random().toString(36).slice(2, 11);
  const today = new Date().toISOString().split('T')[0];

  const services = [
    { id: 's1', name: 'Manicure Simples',   icon: '🌸', duration: 40, price: 45 },
    { id: 's2', name: 'Pedicure Completa',  icon: '🦶', duration: 50, price: 60 },
    { id: 's3', name: 'Gel Alongado',       icon: '💅', duration: 90, price: 120 },
    { id: 's4', name: 'Esmaltação em Gel',  icon: '✨', duration: 60, price: 80  },
    { id: 's5', name: 'Combo Mani + Pedi',  icon: '👑', duration: 90, price: 95  },
  ];
  const insS = db.prepare('INSERT INTO services VALUES (?,?,?,?,?,1)');
  services.forEach(s => insS.run(s.id, s.name, s.icon, s.duration, s.price));

  console.log('✅ Seed de serviços inserido.');
}
seedIfEmpty();

// ══════════════════════════════════════════════════════════
//  ROTAS — SERVIÇOS
// ══════════════════════════════════════════════════════════

// GET /api/services
app.get('/api/services', (req, res) => {
  const services = db.prepare('SELECT * FROM services WHERE active = 1').all();
  res.json(services);
});

// PATCH /api/services/:id
app.patch('/api/services/:id', (req, res) => {
  const { name, icon, duration, price } = req.body;
  db.prepare(`
    UPDATE services SET name=?, icon=?, duration=?, price=? WHERE id=?
  `).run(name, icon, duration, price, req.params.id);
  res.json(db.prepare('SELECT * FROM services').all());
});

// ══════════════════════════════════════════════════════════
//  ROTAS — CLIENTES
// ══════════════════════════════════════════════════════════

// GET /api/clients
app.get('/api/clients', (req, res) => {
  const clients = db.prepare('SELECT * FROM clients ORDER BY name').all();
  res.json(clients);
});

// POST /api/clients
app.post('/api/clients', (req, res) => {
  const { name, phone, email, notes } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: 'Nome obrigatório' });
  if (!phone?.trim()) return res.status(400).json({ error: 'Telefone obrigatório' });

  const id = 'c' + Date.now();
  db.prepare(`
    INSERT INTO clients (id, name, phone, email, notes)
    VALUES (?, ?, ?, ?, ?)
  `).run(id, name.trim(), phone.trim(), email || '', notes || '');

  res.status(201).json(db.prepare('SELECT * FROM clients WHERE id=?').get(id));
});

// PATCH /api/clients/:id
app.patch('/api/clients/:id', (req, res) => {
  const { name, phone, email, notes } = req.body;
  db.prepare(`
    UPDATE clients SET name=?, phone=?, email=?, notes=?, updated_at=datetime('now') WHERE id=?
  `).run(name, phone, email || '', notes || '', req.params.id);
  res.json(db.prepare('SELECT * FROM clients WHERE id=?').get(req.params.id));
});

// ══════════════════════════════════════════════════════════
//  ROTAS — AGENDAMENTOS
// ══════════════════════════════════════════════════════════

// Helper para enriquecer agendamento com nome do serviço
function enrichAppt(appt) {
  if (!appt) return null;
  const svc = db.prepare('SELECT * FROM services WHERE id=?').get(appt.serviceId);
  return { ...appt, serviceName: svc?.name || '', serviceIcon: svc?.icon || '', servicePrice: svc?.price || 0, serviceDuration: svc?.duration || 0 };
}

// GET /api/appointments
app.get('/api/appointments', (req, res) => {
  const { clientId, date, status } = req.query;
  let query = 'SELECT * FROM appointments WHERE 1=1';
  const params = [];

  if (clientId) { query += ' AND client_id=?'; params.push(clientId); }
  if (date)     { query += ' AND date=?';       params.push(date); }
  if (status)   { query += ' AND status=?';     params.push(status); }

  query += ' ORDER BY date ASC, time ASC';
  const appts = db.prepare(query).all(...params).map(enrichAppt);
  res.json(appts);
});

// POST /api/appointments — Cliente cria agendamento
app.post('/api/appointments', async (req, res) => {
  const { clientId, clientName, clientPhone, serviceId, date, time, notes, status } = req.body;
  if (!date || !time || !serviceId) {
    return res.status(400).json({ error: 'date, time e serviceId são obrigatórios' });
  }

  // Verifica conflito de horário
  const conflict = db.prepare(`
    SELECT id FROM appointments WHERE date=? AND time=? AND status != 'cancelled'
  `).get(date, time);
  if (conflict) return res.status(409).json({ error: 'Horário já ocupado' });

  const id  = 'a' + Date.now();
  const svc = db.prepare('SELECT * FROM services WHERE id=?').get(serviceId);

  db.prepare(`
    INSERT INTO appointments
      (id, client_id, clientName, clientPhone, serviceId, serviceName, date, time, status, notes)
    VALUES (?,?,?,?,?,?,?,?,?,?)
  `).run(
    id,
    clientId   || null,
    clientName || 'Cliente',
    clientPhone || '',
    serviceId,
    svc?.name  || '',
    date, time,
    status || 'pending',
    notes || ''
  );

  const appt = enrichAppt(db.prepare('SELECT * FROM appointments WHERE id=?').get(id));

  // 🔔 Notifica o DONO sobre novo agendamento
  notifyOwnerNewBooking(appt).catch(console.error);

  res.status(201).json(appt);
});

// PATCH /api/appointments/:id — Atualiza status (confirmar, cancelar, concluir)
app.patch('/api/appointments/:id', async (req, res) => {
  const { status, notes } = req.body;
  const old = db.prepare('SELECT * FROM appointments WHERE id=?').get(req.params.id);
  if (!old) return res.status(404).json({ error: 'Agendamento não encontrado' });

  const updates = [];
  const params  = [];
  if (status !== undefined) { updates.push('status=?');       params.push(status); }
  if (notes  !== undefined) { updates.push('notes=?');        params.push(notes); }
  updates.push("updated_at=datetime('now')");
  params.push(req.params.id);

  db.prepare(`UPDATE appointments SET ${updates.join(',')} WHERE id=?`).run(...params);
  const appt = enrichAppt(db.prepare('SELECT * FROM appointments WHERE id=?').get(req.params.id));

  // 🔔 Envia WhatsApp quando o dono CONFIRMAR o agendamento
  if (status === 'confirmed' && old.status !== 'confirmed') {
    console.log(`📲 Agendamento confirmado — enviando WhatsApp para ${appt.clientName}`);
    notifyConfirmation(appt).catch(console.error);
  }

  res.json(appt);
});

// ══════════════════════════════════════════════════════════
//  ROTA — TESTE DE WHATSAPP
// ══════════════════════════════════════════════════════════
app.post('/api/test-whatsapp', async (req, res) => {
  const { phone, message } = req.body;
  if (!phone || !message) return res.status(400).json({ error: 'phone e message obrigatórios' });
  const { sendWhatsApp } = require('./whatsapp');
  const result = await sendWhatsApp(phone, message);
  res.json({ ok: true, result });
});

// ══════════════════════════════════════════════════════════
//  INICIALIZAÇÃO
// ══════════════════════════════════════════════════════════

// Inicia o cron de lembretes
startScheduler(db);

app.listen(PORT, () => {
  console.log(`
  ╔════════════════════════════════════════╗
  ║   💅 Belle Studio — Backend Online    ║
  ║   http://localhost:${PORT}               ║
  ╚════════════════════════════════════════╝

  📲 WhatsApp: ${process.env.WHATSAPP_PROVIDER || 'evolution'}
  🗄️  Banco:    belle.db (SQLite)
  ⏰ Lembretes: ativos (a cada 30 min)
  `);
});

module.exports = { app, db };
