# 💅 Belle Studio — Backend com WhatsApp

## O que este backend faz

| Evento | Quem recebe | Mensagem |
|--------|-------------|----------|
| Cliente faz agendamento | **Dono** | "Novo agendamento! Maria Oliveira – Manicure às 09:00" |
| Dono **confirma** o agendamento | **Cliente** | "Seu agendamento foi confirmado! 📅 Sex, 14 mar às 09:00" |
| **1 dia antes** do atendimento | **Cliente** | "Lembrete: amanhã você tem atendimento às 09:00" |
| **1 hora antes** do atendimento | **Cliente + Dono** | "Daqui 1 hora! Maria Oliveira – 09:00" |

---

## Pré-requisitos

- **Node.js 18+** instalado → https://nodejs.org
- Uma conta de **WhatsApp API** (veja opções abaixo)

---

## 1. Instalar dependências

```bash
cd belle-studio-backend
npm install
```

---

## 2. Configurar o arquivo .env

```bash
cp .env.example .env
```

Abra o `.env` e preencha:

```env
PORT=3001
OWNER_PASSWORD=belle123
SALON_NAME=Belle Studio
OWNER_WHATSAPP=5511999990000   # Seu número (recebe alertas)

# Escolha o provedor:
WHATSAPP_PROVIDER=evolution    # ou "twilio"
```

---

## 3. Escolha o provedor WhatsApp

### Opção A — Evolution API (gratuito, recomendado 🇧🇷)

É gratuito, open-source e muito usado no Brasil. Não precisa de aprovação da Meta.

**Instalar localmente com Docker:**
```bash
docker run -d \
  --name evolution-api \
  -p 8080:8080 \
  -e AUTHENTICATION_API_KEY=sua-chave-aqui \
  atendai/evolution-api:latest
```

**Configurar no .env:**
```env
WHATSAPP_PROVIDER=evolution
EVOLUTION_API_URL=http://localhost:8080
EVOLUTION_API_KEY=sua-chave-aqui
EVOLUTION_INSTANCE=belle-studio
```

**Conectar o WhatsApp:**
1. Acesse http://localhost:8080
2. Crie uma instância chamada `belle-studio`
3. Escaneie o QR Code com o WhatsApp do salão

> 📖 Docs completas: https://doc.evolution-api.com

---

### Opção B — Twilio (pago, muito confiável)

R$ ~0,04 por mensagem. Tem sandbox gratuito para testes.

1. Crie conta em https://twilio.com
2. Ative o **WhatsApp Sandbox** (gratuito para testes)
3. Para produção, solicite aprovação de número oficial

**Configurar no .env:**
```env
WHATSAPP_PROVIDER=twilio
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxx
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
```

---

## 4. Iniciar o servidor

```bash
npm start        # produção
npm run dev      # desenvolvimento (reinicia automaticamente)
```

Você verá:
```
╔════════════════════════════════════════╗
║   💅 Belle Studio — Backend Online    ║
║   http://localhost:3001               ║
╚════════════════════════════════════════╝
```

---

## 5. Conectar o frontend

Abra o arquivo `belle-studio-v3.html` e localize a linha:

```javascript
const BACKEND_URL = null; // null = modo demo (localStorage)
```

Troque para:

```javascript
const BACKEND_URL = 'http://localhost:3001';
```

Agora o frontend usa o backend real com WhatsApp. ✅

> **Dica:** Coloque o `belle-studio-v3.html` dentro da pasta `belle-studio-backend/public/`
> para servir tudo pelo mesmo servidor em `http://localhost:3001`.

---

## 6. Testar o WhatsApp

```bash
curl -X POST http://localhost:3001/api/test-whatsapp \
  -H "Content-Type: application/json" \
  -d '{"phone":"5511999990000","message":"Teste Belle Studio! 💅"}'
```

---

## Estrutura dos arquivos

```
belle-studio-backend/
├── server.js        ← Servidor Express + rotas + banco SQLite
├── whatsapp.js      ← Serviço de envio (Evolution API / Twilio)
├── scheduler.js     ← Cron jobs (lembretes 1 dia e 1 hora antes)
├── package.json
├── .env.example     ← Copie para .env e preencha
├── belle.db         ← Banco SQLite (criado automaticamente)
└── public/
    └── belle-studio-v3.html  ← Frontend (opcional)
```

---

## Como os lembretes funcionam

O scheduler roda a cada **30 minutos** e verifica:

1. **Lembrete D-1:** Se um agendamento confirmado for **amanhã** e ainda não enviou o lembrete → envia para a cliente
2. **Lembrete H-1:** Se um agendamento confirmado for **hoje** e o horário estiver na janela de +1h → envia para cliente e dono

Os campos `reminded_day` e `reminded_hour` no banco garantem que cada lembrete seja enviado **apenas uma vez**.

---

## Dúvidas frequentes

**O WhatsApp precisa ficar conectado?**
Sim. Com a Evolution API, o número precisa estar conectado ao QR Code. Use um número dedicado para o salão.

**Posso usar meu número pessoal?**
Tecnicamente sim, mas recomendamos um número exclusivo para o salão para não misturar mensagens pessoais.

**E se o WhatsApp falhar?**
O sistema não quebra. Erros de envio são apenas logados no console, e o agendamento continua normalmente.
